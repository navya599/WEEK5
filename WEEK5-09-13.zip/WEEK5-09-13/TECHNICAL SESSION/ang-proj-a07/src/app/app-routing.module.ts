import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './component/home-page/home-page.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { ContactUsComponent } from './component/contact-us/contact-us.component';
import { PageNotFoundComponent } from './component/page-not-found/page-not-found.component';
import { ParentComponent } from './component/parent/parent.component';
import { ChildComponent } from './component/child/child.component';
import { SwitchComponent } from './component/switch/switch.component';
import { UserAddComponent } from './component/user-add/user-add.component';
import { Ngclass1Component } from './component/ngclass1/ngclass1.component';
import { Ngclass2Component } from './component/ngclass2/ngclass2.component';
import { Ngclass3Component } from './component/ngclass3/ngclass3.component';
import { Ngclass4Component } from './component/ngclass4/ngclass4.component';
import { NgstyleComponent } from './component/ngstyle/ngstyle.component';
import { UserListComponent } from './component/user-list/user-list.component';
import { UserEditComponent } from './component/user-edit/user-edit.component';

const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'contact', component:ContactUsComponent},
  {path:'about', component:AboutUsComponent},
  {path:'parent', component:ParentComponent},
  {path:'child', component:ChildComponent},
  {path:'switch', component:SwitchComponent},
  {path:'useradd', component:UserAddComponent},
  {path:'ngstyle', component:NgstyleComponent},
  {path:'ngclass1', component:Ngclass1Component},
  {path:'ngclass2', component:Ngclass2Component},
  {path:'ngclass3', component:Ngclass3Component},
  {path:'ngclass4', component:Ngclass4Component},
  {path:'user-list', component:UserListComponent},
  {path:'useredit', component:UserEditComponent},
  {path:'user-add', component:UserAddComponent},
  {path:'**', component:PageNotFoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
