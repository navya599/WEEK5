import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngstyle',
  templateUrl: './ngstyle.component.html',
  styleUrls: ['./ngstyle.component.css']
})
export class NgstyleComponent implements OnInit {
  style1 = {'background-color':'blue', color:'white', border:'5px solid red'}

  func1() {
    this.style1 = {'background-color':'green', color:'black', border:'5px solid aqua'}
  }
  constructor() { }

  ngOnInit(): void {
  }

}
