import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {
  id:any
  user_name:string = ''
  email_id:string = ''
  pass_word:string = ''
  message = ''

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }
  addUser = () => {
    //alert('You submitted the form')
    let obj = {id:this.id, user_name:this.user_name, email_id:this.email_id, pass_word:this.pass_word}

    this.http.post("http://localhost:5555/user", obj).subscribe(
      (result) => {
        console.log('Inserted')
        console.log(result)
      }
    )
  }

  clearMessage() {
    this.message = ''
  }


}