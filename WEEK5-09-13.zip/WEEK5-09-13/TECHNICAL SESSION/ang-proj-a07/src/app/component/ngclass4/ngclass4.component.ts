import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass4',
  templateUrl: './ngclass4.component.html',
  styleUrls: ['./ngclass4.component.css']
})
export class Ngclass4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
