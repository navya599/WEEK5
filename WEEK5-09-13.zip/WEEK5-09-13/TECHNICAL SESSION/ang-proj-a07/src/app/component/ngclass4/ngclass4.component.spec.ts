import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ngclass4Component } from './ngclass4.component';

describe('Ngclass4Component', () => {
  let component: Ngclass4Component;
  let fixture: ComponentFixture<Ngclass4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ngclass4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ngclass4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
