import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass3',
  templateUrl: './ngclass3.component.html',
  styleUrls: ['./ngclass3.component.css']
})
export class Ngclass3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
