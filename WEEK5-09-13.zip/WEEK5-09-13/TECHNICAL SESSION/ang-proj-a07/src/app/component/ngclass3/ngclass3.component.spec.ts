import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ngclass3Component } from './ngclass3.component';

describe('Ngclass3Component', () => {
  let component: Ngclass3Component;
  let fixture: ComponentFixture<Ngclass3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ngclass3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ngclass3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
