import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass1',
  templateUrl: './ngclass1.component.html',
  styleUrls: ['./ngclass1.component.css']
})
export class Ngclass1Component implements OnInit {
  employees: any[] = [
    { "name": "Amar",    "skill": 'Angular' },
    { "name": "Panner Selvam","skill": 'Java' },
    { "name": "Naren",   "skill": 'Testing' },
    { "name": "Srinivas", "skill": 'Angular' },
    { "name": "Kanchana","skill": 'Java' },
    { "name": "Saranya",  "skill": 'Testing' }
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
